# t-dev-800-workspace
Repository qui contient le docker compose et les repository de l'api et du front

## Git, Git Submodules
Le repository T-DEV-800-WORKSPACE est le repository **main**, il contient le fichier **compose.yaml** et les 2 autres repository (front et api).

L'utilisation des submodules peut-être un peu déroutant si vous n'avez pas l'habitude, c'est pourquoi je vais vous expliquer étape par étape pour mettre en place le projet une fois que vous avez cloner le repo T-DEV-800-WORKSPACE.

Etapes :
1. Cloner le repo t-dev-800-workspace en ssh
2. Lancer dans votre terminal la première commande : **git submodule init**

    2.1 **Explication git submodule init** : Cette commande est utilisée pour initialiser vos sous-modules locaux. Lorsque vous exécutez cette commande, Git crée un fichier **.gitmodules** dans votre dépôt principal qui stocke les métadonnées des sous-modules, y compris l'URL du dépôt distant et le chemin où le sous-module est stocké dans votre dépôt principal. Cette commande ne récupère pas le code du sous-module, elle prépare simplement votre dépôt pour travailler avec le sous-module.
3. Lancer ensuite la commande : **git submodule update**

    3.1 **Explication git submodule update** : Cette commande est utilisée pour récupérer le code du sous-module. Lorsque vous exécutez cette commande, Git va chercher le code du sous-module à l'URL spécifiée dans le fichier .gitmodules et le place dans le chemin spécifié. Par défaut, cette commande laisse le sous-module en mode "HEAD détachée", ce qui signifie qu'il n'est pas sur une branche spécifique mais sur un commit spécifique.

4. A présent vous pouvez aller dans les repo ou vous souhaitez travailler et récupérer les branches distantes propriétaire au repository en question : **git fetch --all**

5. Vous verrez que "HEAD est détachée", ce qui signifie qu'il n'est pas sur une branche spécifique mais sur un commit spécifique. Faite un petit coup de git status pour vous assurez que aucun fichier que vous ne souhaitez pas est traquer : **git status**

6. Ne vous reste plus qu'a aller sur la branch que vous souhaitez, par exemple : **git checkout main** et ensuite vous pouvez créer une nouvelle branche à partir de la branche principale


## Pour lancer les conteneurs Docker, suivre les étapes suivantes :

1. Copier le fichier **.env** en un nouveau ficher **.env.dev.local**
2. Editer les variables d'environnement

    2.1 Exemple :
- POSTGRES_VERSION=laversion
- POSTGRES_DB=lenomdeladb
- POSTGRES_USER=lenomdelutilisateur
- POSTGRES_PASSWORD=lemotdepasse

3. Lancer la commande suivante :\
**docker compose --env-file ./PixManagerAPI/.env.dev.local up -d**\
Explication : permet de spécifier le fichier d'environnement que l'on souhaite utiliser au compose.yaml
